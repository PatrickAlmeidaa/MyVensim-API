var searchData=
[
  ['debuging_0',['DEBUGING',['../_handle_body_8h.html#aeff79046387df0de04e7de11061a704b',1,'DEBUGING():&#160;HandleBody.h'],['../funcional_2main_8cpp.html#aeff79046387df0de04e7de11061a704b',1,'DEBUGING():&#160;main.cpp'],['../unit_2main_8cpp.html#aeff79046387df0de04e7de11061a704b',1,'DEBUGING():&#160;main.cpp']]]
];
