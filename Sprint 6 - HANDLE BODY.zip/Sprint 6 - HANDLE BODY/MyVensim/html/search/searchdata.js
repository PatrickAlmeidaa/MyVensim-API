var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuv~",
  1: "bcefhlmsu",
  2: "fhmsu",
  3: "abcdefghilmorsu~",
  4: "dfmnpstv",
  5: "fms",
  6: "dm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos",
  6: "Definições e Macros"
};

