var searchData=
[
  ['flowbody_0',['FlowBody',['../class_flow_body.html#a376bdda0cab04822f24dcf64c3ba975d',1,'FlowBody::FlowBody(const FlowBody &amp;f)'],['../class_flow_body.html#a0daa308cb1aef965f24da1f2fed283a8',1,'FlowBody::FlowBody(string name=&quot;&quot;, System *Source=NULL, System *Destiny=NULL)']]],
  ['flowhandle_1',['FlowHandle',['../class_flow_handle.html#adc8ee9eca0d2fd4c2a89283d69fd0cfa',1,'FlowHandle::FlowHandle(const FlowHandle &amp;flow)'],['../class_flow_handle.html#a80190876156c2d4c24cc6725cd35638b',1,'FlowHandle::FlowHandle(string name=&quot;&quot;, System *source=NULL, System *destiny=NULL)']]]
];
