#ifndef MYVENSIM_UNIT_FLOW_H
#define MYVENSIM_UNIT_FLOW_H

void unit_Flow_constructor();
void unit_flow_copy_constructor();
void unit_Flow_destructor();

void unit_Flow_setName();
void unit_Flow_setDestiny();
void unit_Flow_setSource();

void unit_Flow_getName();
void unit_Flow_getDestiny();
void unit_Flow_getSource();

void unit_Flow_operator();

void run_unit_tests_Flow();

#endif
