#ifndef MYVENSIM_UNIT_SYSTEM_H
#define MYVENSIM_UNIT_SYSTEM_H

void unit_System_constructor();
void unit_System_copy_constructor();
void unit_System_destructor();

void unit_System_setName();
void unit_System_setValue();

void unit_System_getName();
void unit_System_getValue();

void unit_System_operator();

void run_unit_tests_System();

#endif
