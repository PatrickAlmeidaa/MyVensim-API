#include "../../src/FlowImpl.h"
#include "../../src/SystemImpl.h"
#include "unit_flow.h"
#include <assert.h>

class Unit : public FlowBody{
public:
    Unit(string name = "", System* source = NULL, System* Destiny = NULL){
        setName(name);
        setSource(source);
        setDestiny(Destiny);
    }

    double execute(){
        return 1 + getSource()->getValue();
    }
};

void unit_Flow_constructor(){
/*!< Teste para o construtor de Flow*/
    System *sys1 = new SystemHandle("s1", 10.0);
    System *sys2 = new SystemHandle("s2", 10.0);

    Flow *aux_temp2 = new FlowHandle<Unit>("test 1", sys1, sys2);

    assert(aux_temp2->getName() == "test 1");
    assert(aux_temp2->getSource() == sys1);
    assert(aux_temp2->getDestiny() == sys2);

}
void unit_flow_copy_constructor(){
    System *sys1 = new SystemHandle("s1", 10.0);
    System *sys2 = new SystemHandle("s2", 10.0);

    FlowHandle<Unit> *aux_temp2 = new FlowHandle<Unit>("test op", sys1, sys2);
    Flow *test = new FlowHandle<Unit>(*aux_temp2);

    assert(test->getName() == "test op");
    assert(test->getSource() == sys1);
    assert(test->getDestiny() == sys2);

}

void unit_Flow_destructor(){ }/*!< Teste para o destrutor de Flow*/

void unit_Flow_setName(){
/*!< Teste para setName de Flow*/
    Flow *aux_temp2 = new FlowHandle<Unit>("", NULL, NULL);
    aux_temp2->setName("test set name");

    assert(aux_temp2->getName() == "test set name");

}

void unit_Flow_setDestiny(){
/*!< Teste para setDestiny de Flow*/
    System *sys2 = new SystemHandle("s2", 100.0);

    Flow *aux_temp2 = new FlowHandle<Unit>("test set dest", NULL, sys2);
    aux_temp2->setDestiny(sys2);

    assert(aux_temp2->getDestiny() == sys2);

}

void unit_Flow_setSource(){
/*!< Teste para setSource de Flow*/
    System *sys = new SystemHandle("s2", 100.0);

    Flow *aux_temp2 = new FlowHandle<Unit>("test set source", sys, NULL);
    aux_temp2->setDestiny(sys);

    assert(aux_temp2->getDestiny() == sys);

}

void unit_Flow_getName(){
/*!< Teste para getName de Flow*/
    Flow *aux_temp2 = new FlowHandle<Unit>("test get name", NULL, NULL);

    assert(aux_temp2->getName() == "test get name");

}

void unit_Flow_getDestiny(){
/*!< Teste para getDestiny de Flow*/
    System *sys2 = new SystemHandle("s2", 10.0); 

    Flow *aux_temp2 = new FlowHandle<Unit>("test get dest", NULL, sys2);

    assert(aux_temp2->getDestiny() == sys2);

}

void unit_Flow_getSource(){
/*!< Teste para getSource de Flow*/
    System *sys = new SystemHandle("s2", 10.0); 

    Flow *aux_temp2 = new FlowHandle<Unit>("test get source", sys, NULL);

    assert(aux_temp2->getSource() == sys);

}

void unit_Flow_operator(){
/*!< Teste para operador = de Flow*/
    System *sys1 = new SystemHandle("s1", 10.0);
    System *sys2 = new SystemHandle("s2", 10.0);

    Flow *aux_temp2 = new FlowHandle<Unit>("test op", sys1, sys2);
    Flow *test = new FlowHandle<Unit>();
    test = aux_temp2;

    assert(test->getName() == "test op");
    assert(test->getSource() == sys1);
    assert(test->getDestiny() == sys2);

}

void run_unit_tests_Flow(){
/*!< Roda todos os testes de Flow*/
    unit_Flow_constructor();
    unit_flow_copy_constructor();
    unit_Flow_destructor();

    unit_Flow_setName();
    unit_Flow_setDestiny();
    unit_Flow_setSource();

    unit_Flow_getName();
    unit_Flow_getDestiny();
    unit_Flow_getSource();

    unit_Flow_operator();
}