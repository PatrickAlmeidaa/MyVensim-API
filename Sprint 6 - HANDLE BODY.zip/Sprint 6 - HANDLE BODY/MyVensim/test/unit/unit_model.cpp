#include "unit_model.h"
#include <assert.h>
#include <math.h>
#include "../../src/Model.h"

class UnitM : public FlowBody{
public:
    UnitM(string name = "", System* source = NULL, System* Destiny = NULL){
        setName(name);
        setSource(source);
        setDestiny(Destiny);
    }

    double execute(){
        return 0.01 * getSource()->getValue();
    }
};

void unit_Model_constructor(){
/*!< Teste para o construtor de Model*/
    Model *m = Model::createModel("test constructor", 100.0);
    System* pop1 = m->createSystem("P1", 100);
    System* pop2 = m->createSystem("P2", 0);
    Flow* f = m->createFlow<UnitM>("test", pop1, pop2);

    assert(m->getName() == "test constructor");
    assert(m->getTime() == 100.0);
    assert(m->getSystem(0) == pop1);
    assert(m->getSystem(1) == pop2);
    assert(m->getFlow(0) == f);

    delete m;
}

void unit_Model_destructor(){}/*!< Teste para o destrutor de Model*/

void unit_Model_setName(){
/*!< Teste para setName de Model*/
    Model *m = Model::createModel("", 100.0);

    m->setName("set name test");

    assert(m->getName() == "set name test");

    delete m;
}

void unit_Model_setTime(){
/*!< Teste para setTime de Model*/
    Model *m = Model::createModel("test", 0.0);
    
    m->setTime(50.0);

    assert(m->getTime() == 50.0);

    delete m;
}

void unit_Model_getName(){
/*!< Teste para getName de Model*/
    Model *m = Model::createModel("get name test", 100.0);

    assert(m->getName() == "get name test");

    delete m;
}

void unit_Model_getTime(){
/*!< Teste para getTime de Model*/
    Model *m = Model::createModel("test", 50.0);

    assert(m->getTime() == 50.0);

    delete m;
}

void unit_Model_getSystem(){
/*!< Teste para getSystem de Model*/
    Model *m = Model::createModel("test get system", 100.0);
    System* pop1 = m->createSystem("P1", 100);
    System* pop2 = m->createSystem("P2", 0);

    assert(m->getSystem(0) == pop1);
    assert(m->getSystem(1) == pop2);

    delete m;
}

void unit_Model_getFlow(){
/*!< Teste para getFlow de Model*/
    Model *m = Model::createModel("test get flow", 100.0);
    Flow* f = m->createFlow<UnitM>("test", NULL, NULL);

    assert(m->getFlow(0) == f);

    delete m;
}

void unit_Model_execute(){
/*!< Teste para execute*/
    Model *m = Model::createModel("test execute", 0.0);
    System* pop1 = m->createSystem("P1", 100);
    System* pop2 = m->createSystem("P2", 0);
    Flow* f = m->createFlow<UnitM>("test", pop1, pop2);

    m->execute(0, 100);

    assert(fabs(pop1->getValue() - 36.6032) < 0.0001);
    assert(fabs(pop2->getValue() - 63.3968) < 0.0001);

    delete m;
}

void unit_Model_addSystem(){
/*!< Teste para addSystem*/
    Model *m = Model::createModel("test add system", 100.0);
    System* pop1 = m->createSystem("P1", 100);
    System* pop2 = m->createSystem("P2", 0);

    assert(m->getSystem(0) == pop1);
    assert(m->getSystem(1) == pop2);

    delete m;
}

void unit_Model_addFlow(){
/*!< Teste para addFlow*/
    Model *m = Model::createModel("test add flow", 100.0);
    Flow* f = m->createFlow<UnitM>("test", NULL, NULL);

    assert(m->getFlow(0) == f);

    delete m;
}

void unit_Model_operator(){
/*!< Teste para operador = de Model*/
    Model *m = Model::createModel("test operator", 100.0);
    System* pop1 = m->createSystem("P1", 100);
    System* pop2 = m->createSystem("P2", 0);
    Flow* f = m->createFlow<UnitM>("test", pop1, pop2);
    Model *test;

    test = m;

    assert(test->getName() == "test operator");
    assert(test->getSystem(0) == pop1);
    assert(test->getSystem(1) == pop2);
    assert(test->getFlow(0) == f);
}

void run_unit_tests_Model(){
/*!< Roda todos os testes de Model*/
    unit_Model_constructor();
    unit_Model_destructor();

    unit_Model_setName();
    unit_Model_setTime();

    unit_Model_getName();
    unit_Model_getTime();
    unit_Model_getSystem();
    unit_Model_getFlow();

    unit_Model_execute();
    unit_Model_addSystem();
    unit_Model_addFlow();

    unit_Model_operator();
}