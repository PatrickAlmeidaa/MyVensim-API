#include "unit_tests.h"
#include <assert.h>
#include <iostream>

#define DEBUGING
#ifdef DEBUGING
int numHandleCreated = 0;
int numHandleDeleted = 0;
int numBodyCreated = 0;
int numBodyDeleted = 0;
#endif

using namespace std;

int main(){
    run_unit_tests_globals();
    unit_test_handlebody();
    cout << "---Testes finalizados com sucesso---" << endl;
    return 0;
}
