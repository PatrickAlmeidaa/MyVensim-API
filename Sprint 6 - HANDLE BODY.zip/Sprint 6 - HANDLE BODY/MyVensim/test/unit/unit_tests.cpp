#include "unit_flow.h"
#include "unit_model.h"
#include "unit_system.h"
#include "unit_tests.h"
#include "../../src/SystemImpl.h"
#include <assert.h>
#include <iostream>

using namespace std;

void unit_test_handlebody(){
    {
        SystemHandle sys1 ("Population 1", 10.0);
        SystemHandle sys2 ("Population 2", 10.0);

        sys1 = sys2;

        cout << "Created handles: "  << numHandleCreated << endl;
        cout << "Deleted handles: "  << numHandleDeleted << endl;
        cout << "Created bodies: "  << numBodyCreated << endl;
        cout << "Deleted bodies: "  << numBodyDeleted << endl;

    }
}

void run_unit_tests_globals(){
    run_unit_tests_Model();
    
    cout << "---Model OK---" << endl;
    run_unit_tests_Flow();
    
    cout << "---Flow OK---" << endl;
    run_unit_tests_System();
    
    cout << "---System OK---" << endl;
}