#include "../../src/SystemImpl.h"
#include "unit_system.h"
#include <assert.h>

using namespace std;

void unit_System_constructor(){
/*!< Teste para o construtor de System*/
    System *aux_temp = new SystemHandle("p1", 100.0);
    assert(aux_temp->getName() == "p1");
    assert(aux_temp->getValue() == 100.0);
}

void unit_System_copy_constructor(){
    SystemHandle *aux_temp = new SystemHandle("p1", 100.0);
    SystemHandle *s_test = new SystemHandle(*aux_temp);

    aux_temp->setName("new p1");
    aux_temp->setValue(50.0);

    assert(s_test->getValue() == 50.0);
    assert(s_test->getName() == "new p1");
}

void unit_System_destructor(){ }/*!< Teste para o destrutor de System*/

void unit_System_setName(){
/*!< Teste para o setName de System*/
    System *s = new SystemHandle();
    s->setName("p1");
    assert(s->getName() == "p1");
}

void unit_System_setValue(){
/*!< Teste para o setValue de System*/
    System *s = new SystemHandle();
    s->setValue(10.0);
    assert(s->getValue() == 10.0);
}

void unit_System_getName(){
/*!< Teste para o getName de System*/
    System *s = new SystemHandle("p1", 10.0);
    assert(s->getName() == "p1");
}

void unit_System_getValue(){
/*!< Teste para o getValue de System*/
    System *s = new SystemHandle("p1", 10.0);
    assert(s->getValue() == 10.0);
}

void unit_System_operator(){
/*!< Teste para operador = de System*/
    SystemHandle *aux_temp = new SystemHandle("p1", 100.0);
    SystemHandle *s_test = new SystemHandle();

    s_test = aux_temp;

    aux_temp->setName("new p1");
    aux_temp->setValue(50.0);

    assert(s_test->getValue() == 50.0);
    assert(s_test->getName() == "new p1");
}

void run_unit_tests_System(){
/*!< Roda todos os testes de System*/
    unit_System_constructor();
    unit_System_copy_constructor();
    unit_System_destructor();

    unit_System_setName();
    unit_System_setValue();

    unit_System_getName();
    unit_System_getValue();

    unit_System_operator();
}