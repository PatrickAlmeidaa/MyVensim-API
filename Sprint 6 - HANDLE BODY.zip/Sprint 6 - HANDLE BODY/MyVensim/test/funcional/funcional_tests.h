#ifndef FUNCTIONAL_TEST
#define FUNCTIONAL_TEST
#include "../../src/Model.h"
class Exponencial : public FlowBody{
    public:
        /*!
            This is a more elaborated constructor for the ExponencialFlow Class.
            \param name the name of the ExponencialFlow Class.
            \param source a pointer to the source system of the ExponencialFlow Class.
            \param target a pointer to the target system of the ExponencialFlow Class.
        */
        Exponencial(string name="", System* source=NULL, System* target=NULL){
            setName(name);
            setSource(source);
            setDestiny(target);
        }

        /*!
            A method created by the user, that contains an equation that will be executed by the exponencial model.                        
        */
        double execute(){
            return (0.01 * getSource()->getValue());
        }
};

class Logistic : public FlowBody{
    public:
        /*!
            This is a more elaborated constructor for the LogisticFlow Class.
            \param name the name of the LogisticFlow Class.
            \param source a pointer to the source system of the LogisticFlow Class.
            \param target a pointer to the target system of the LogisticFlow Class.
        */
        Logistic(string name="", System* source=NULL, System* target=NULL){
            setName(name);
            setSource(source);
            setDestiny(target);
        }

        /*!
            A method created by the user, that contains an equation that will be executed by the logistic model.                        
        */
        double execute(){
            return 0.01 * getDestiny()->getValue() * (1 - getDestiny()->getValue() / 70);
        }
};

class Complex : public FlowBody{
    public:
        /*!
            This is a more elaborated constructor for the ComplexFlowF Class.
            \param name the name of the ComplexFlowF Class.
            \param source a pointer to the source system of the ComplexFlowF Class.
            \param target a pointer to the target system of the ComplexFlowF Class.
        */
        Complex(string name="", System* source=NULL, System* target=NULL){
            setName(name);
            setSource(source);
            setDestiny(target);
        }

        /*!
            A method created by the user, that contains an equation that will be executed by the complex model.                        
        */
        double execute(){
            return 0.01 * getSource()->getValue();
        }
};
#endif

/*!< Função que roda o teste exponencial */
void exponentialFuncionalTest();

/*!< Função qeu roda o teste de logística*/
void logisticalFuncionalTest();

/*!< Função que roda o teste complexo*/
void complexFuncionalTest();