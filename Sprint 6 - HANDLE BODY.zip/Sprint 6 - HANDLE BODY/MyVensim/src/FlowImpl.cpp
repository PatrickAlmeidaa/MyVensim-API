#include "FlowImpl.h"

FlowBody::FlowBody (const FlowBody& f){
    if (this == &f){
        return;
    }
    
    name = f.getName();
    Source = f.getSource();
    Destiny = f.getDestiny();
}

FlowBody::FlowBody(string name, System* Source, System* Destiny):name(name), Source(Source), Destiny(Destiny){}

FlowBody::~FlowBody(){}

string FlowBody::getName() const {
    return name;
}
        
void FlowBody::setName(string Name_f){
    name = Name_f;
}

System* FlowBody::getSource() const{
    return Source; 
}

void FlowBody::setSource(System* SourceSys){
    Source = SourceSys;
}

System* FlowBody::getDestiny() const {
    return Destiny;
}

void FlowBody::setDestiny(System* DestinySys) {
    Destiny = DestinySys;
}

/*FlowBody& FlowBody::operator=(const Flow& f){
    if (this == &f){
        return *this;
    }

    setName(f.getName());
    setSource(NULL);
    setDestiny(NULL);

    return *this;
}*/