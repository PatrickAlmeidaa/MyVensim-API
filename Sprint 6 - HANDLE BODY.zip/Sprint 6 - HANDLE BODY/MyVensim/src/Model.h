#ifndef MODEL_H
#define MODEL_H

#include <vector>
#include <string>
#include "Flow.h"
#include "System.h"
#include "FlowImpl.h"

using namespace std;

class Model{
public:        
    typedef vector<System*>::iterator systemIt;
    typedef vector<Flow*>::iterator flowIt;
    typedef vector<Model*>::iterator modelIt;

    /*!< Retorna o interador inicial do container de systemas*/
    virtual systemIt initialSystems() = 0;

    /*!< Retorna o interador final do container de systemas*/
    virtual systemIt lastSystems() = 0; 

    /*!< Retorna o interador inicial do container de fluxos*/
    virtual flowIt   initialFlows() = 0; 

    /*!< Retorna o interador final do container de fluxos*/
    virtual flowIt   lastFlow() = 0;

    /*!< Retorna o interador inicial do container de Modelo*/
    virtual modelIt   initialModels() = 0; 

    /*!< Retorna o interador final do container de Modelo*/
    virtual modelIt   lastModel() = 0;

    /*!< Destrutor*/
    virtual ~Model(){}

    /*!
        Roda todos os fluxos presentes no modelo com suas respectivar operações internas
        \param time_i tempo inicial
        \param time_f tempo final
    */
    virtual void execute(double time_i, double time_f) = 0;

    
    /*!
        Fabrica de System.
        \param name_s nome do sistema que será criado
        \param value_s valor do sistema que será criado
        \return obijeto de System
    */
    virtual System* createSystem(string name_s, double value_s) = 0;

    /*!
        Fabrica de Model.
        \param name_m nome do modelo que será criado
        \param time_m tempo de execução do modelo que será criado
        \return obijeto de Model
    */
    static Model* createModel(string name_m, double time_m);
    
    /*!
        Fabrica de Flow.
        \param name_f nome do fluxo que será criado
        \param source_f sitema de origem do fluxo
        \param destiny_f sitema de destino do fluxo
        \return obijeto de Flow
    */
    template <typename T_FLOW>
    Flow* createFlow(string name = "", System* source = NULL, System* target = NULL){
        Flow* flow = new FlowHandle<T_FLOW>(name, source, target);
        addFlow(flow);
        return flow;
    }


    /*!
        Define um novo nome para o modelo
        \param Name_m novo nome do modelo
    */
    virtual void setName(string Name_m) = 0;

    /*!
        Retorna o nome do modelo
        \return nome do modelo
    */
    virtual string getName() const = 0;

    /*!
        Define um novo tempo de execução para o modelo
        \param Time_m novo tempo de execução
    */
    virtual void setTime(double Time_m) = 0;

    /*!
        Retorna o tempo de execução
        \return tempo de execução
    */
    virtual double getTime() const = 0;

    /*!
        Retorna um determinado sistema que está presente no modelo
        \param i posição do container na qual o sistema desejado se encontra
        \return sistema desejado
    */
    virtual System* getSystem(int i) = 0;

    /*!
        Retorna um determinado fluxo que está presente no modelo
        \param i posição do container na qual o fluxo desejado se encontra
        \return fluxo desejado
    */
    virtual Flow* getFlow(int i) = 0;

protected:
    /*!
        Adiciona um sistema ao modelo
        \param s sistema que será adicionado
    */
    virtual void addSystem(System* s) = 0;

    /*!
        Adiciona um fluxo ao modelo
        \param f fluxo que será adicionado
    */
    virtual void addFlow(Flow* f) = 0;
};
#endif