#ifndef SYSTEMIMPL_H
#define SYSTEMIMPL_H

#include "System.h"
#include "HandleBody.h"

using namespace std;

class SystemBody : public Body {
protected:
    string name; /*!< Nome do sistema*/
    double value; /*!< valor do sistema*/

public:
    /*!< Construtor de cópia para o sistema*/
    SystemBody (const SystemBody& sys);

    /*!
        Construtor padrão para System que recebe dois parametros
        \param name nome do sistema
        \param value valor inicial que o sistema recebe
        \return objeto de SystemBody que será usado em Flow e Model
    */
    SystemBody(string name = "", double value = 0.0);

    /*!< Sobrecarga do operador igual*/
    SystemBody& operator=(const SystemBody& sys);

    /*!< Destrutor padão para o sistema*/
    virtual ~SystemBody();

    /*!
        Define um novo nome para o sistema
        \param sysName novo nome do sistema
    */
    void setName(string sysName); 

    /*!
        Retorna o nome do sistema
        \return nome do sistema
    */
    string getName() const;

    /*!
        Define um novo valor para o sistema
        \param sysValue novo valor do sistema
    */
    void setValue(double sysValue);

    /*!
        Retorna o valor do sistema
        \return valor do sistema
    */
    double getValue() const;
};

class SystemHandle : public Handle<SystemBody>, public System {
public:
    SystemHandle (const SystemHandle& sys){
        if (this == &sys){
            return;
        }

        pImpl_->detach();
        pImpl_ = sys.pImpl_;
    }

    SystemHandle(string name = "", double value = 0.0){  
        pImpl_->setName(name);
        pImpl_->setValue(value);
    }

    SystemHandle& operator=(const SystemHandle& sys){
        if(this == &sys){
            return *this;
        }
    
        pImpl_->detach();
        pImpl_ = sys.pImpl_;
        return *this;
    }

    virtual ~SystemHandle(){};

    void setName(string sysName){
        pImpl_->setName(sysName);
    }

    string getName() const{
        return pImpl_->getName();
    }

    void setValue(double sysValue){
        pImpl_->setValue(sysValue);
    }

    double getValue() const{
        return pImpl_->getValue();
    }
};

#endif