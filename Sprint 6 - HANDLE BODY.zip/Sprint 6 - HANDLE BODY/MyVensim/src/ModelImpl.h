#ifndef ModelBody_H
#define ModelBody_H

#include "Model.h"
#include "HandleBody.h"

using namespace std;

class ModelBody : public Body{
protected:
    string name; /*!< Nome do modelo*/
    double time; /*!< Tempo que o modelo executará*/
    vector<System*> Sys; /*!< container para armazenar os sistemas do modelo*/
    vector<Flow*> fl; /*!< container para armazenar os fluxos do modelo*/
    static vector<Model*> models; /*!< container para os ponteiros da interface*/

public:             
    typedef vector<System *>::iterator systemIt;
    typedef vector<Flow *>::iterator flowIt;
    typedef vector<Model*>::iterator modelIt;

    /*!< Retorna o interador inicial do container de systemas*/
    systemIt initialSystems();

    /*!< Retorna o interador final do container de systemas*/
    systemIt lastSystems();

    /*!< Retorna o interador inicial do container de fluxos*/
    flowIt initialFlows();

    /*!< Retorna o interador final do container de fluxos*/
    flowIt lastFlow();

    /*!< Retorna o interador inicial do container de Modelo*/
    modelIt initialModels(); 

    /*!< Retorna o interador final do container de Modelo*/
    modelIt lastModel();

    /*!
        Construtor padrão para Model que recebe dois parametros
        \param name nome do modelo
        \param time valor inicial que o modelo recebe
        \return objeto de ModelBody
    */
    ModelBody(string name="", double time=0.0);

    /*!< destrutor para o modelo*/
    virtual ~ModelBody();

    /*!
        Roda todos os fluxos presentes no modelo com suas respectivar operações internas
        \param time_i tempo inicial
        \param time_f tempo final
    */
    void execute(double time_i=0.0, double time_f=0.0);

    System* createSystem(string name_s, double value_s);

    static Model* createModel(string name_m, double time_m);
 
    /*!
        Define um novo nome para o modelo
        \param Name_m novo nome do modelo
    */
    void setName(string Name_m);

    /*!
        Retorna o nome do modelo
        \return nome do modelo
    */
    string getName() const;

    /*!
        Define um novo tempo de execução para o modelo
        \param Time_m novo tempo de execução
    */
    void setTime(double Time_m);

    /*!
        Retorna o tempo de execução
        \return tempo de execução
    */
    double getTime() const;

    /*!
        Retorna um determinado sistema que está presente no modelo
        \param i posição do container na qual o sistema desejado se encontra
        \return sistema desejado
    */
    System* getSystem(int i);

    /*!
        Retorna um determinado fluxo que está presente no modelo
        \param i posição do container na qual o fluxo desejado se encontra
        \return fluxo desejado
    */
    Flow* getFlow(int i);

    /*!
        Adiciona um sistema ao modelo
        \param s sistema que será adicionado
    */
    void addSystem(System* s);

    /*!
        Adiciona um fluxo ao modelo
        \param f fluxo que será adicionado
    */
    void addFlow(Flow* f);

private:
    /*!< sobrecarga do operador igual*/
    ModelBody& operator=(const ModelBody& model);

    /*!< Construtor de cópia*/
    ModelBody (const ModelBody& model);


};

class ModelHandle : public Handle<ModelBody>, public Model{
protected:
    /*!        
        Adds a system's pointer to the systems vector.
        \param sys the system to be added.
    */ 
    void addSystem(System* sys){
        pImpl_->addSystem(sys);
    }
    
    /*!        
        Adds a flow's pointer to the flows vector. 
        \param flow the flow to be added.
    */ 
    void addFlow(Flow* flow){
        pImpl_->addFlow(flow);
    }

public:
    
    typedef vector<System *>::iterator systemIterator;
    typedef vector<Flow *>::iterator flowIterator;
    typedef vector<Model *>::iterator modelIterator;

    systemIt initialSystems(){
        return pImpl_->initialSystems();
    }
    
    systemIt lastSystems(){
        return pImpl_->lastSystems();
    }

    flowIt initialFlows(){
        return pImpl_->initialFlows();
    }

    flowIt lastFlow(){
        return pImpl_->lastFlow();
    }

    modelIt initialModels(){
        return pImpl_->initialModels();
    }

    modelIt lastModel(){
        return pImpl_->lastModel();
    }

    ModelHandle (const ModelHandle& model){}

    ModelHandle& operator=(const ModelHandle& model){
        if(this == &model){
            return *this;
        }
    
        pImpl_->detach();
        pImpl_ = model.pImpl_;
        return *this;
    }

    ModelHandle(string name="", double time=0.0){
        pImpl_->setName(name);
        pImpl_->setTime(time);
    }
    
    virtual ~ModelHandle(){};
        
    void execute(double start=0.0, double final=0.0){
        pImpl_->execute(start, final);
    }

    System* createSystem(string name="", double value=0.0){
        return pImpl_->createSystem(name, value);
    }

    static Model* createModel(string name="", double time=0.0){
        return ModelBody::createModel(name, time);
    }

    void setName(string modelName){
        pImpl_->setName(modelName);
    }

    string getName() const{
        return pImpl_->getName();
    }

    void setTime(double currentTime){
        pImpl_->setTime(currentTime);
    }

    double getTime() const{
        return pImpl_->getTime();
    }

    System* getSystem(int index){
        return pImpl_->getSystem(index);
    }

    Flow* getFlow(int index){
        return pImpl_->getFlow(index);
    }
};

#endif