#ifndef FlowBody_H
#define FlowBody_H

#include "Flow.h"
#include "HandleBody.h"

using namespace std;

class FlowBody : public Body{
protected:
    string name; /*!< Nome do fluxo*/
    System* Source; /*!< Sistema de origem do fluxo*/
    System* Destiny; /*!< Sistema de Destiny do fluxo*/

public:
    /*!< Construtor de cópia para o fluxo*/
    FlowBody (const FlowBody& f);

    /*!
        Construtor padrão para Flow que recebe três parametros
        \param name nome do fluxo
        \param Source sistema de origem do fluxo
        \param Destiny sistema de Destiny fluxo
        \return objeto de FlowBody que será usado em Model
    */
    FlowBody(string name = "", System* Source = NULL, System* Destiny = NULL);

    /*!< Sobrecarga do operadorde igual*/
    FlowBody& operator=(const Flow& f);
    
    /*!< Destrutor padão para o fluxo*/
    virtual ~FlowBody();
    
    /*!
        Função responsável por executar as operações de fluxo definidas pelo usuário. 
        A definição das operaçoes de fluxo deverão ser feitas por meio de subclasses.
    */
    virtual double execute() = 0;

    /*!
        Define um novo nome para o fluxo
        \param Name_f novo nome do fluxo
    */
    void setName(string Name_f);
   
    /*!
        Retorna o nome do fluxo
        \return nome do fluxo
    */
    string getName() const;

    /*!
        Define um novo sistema de origem para o fluxo
        \param SourceSys novo sistema de origem
    */
    void setSource(System* SourceSys);
   
   /*!
        Retorna sistema de origem
        \return sistema de origem
    */
    System* getSource() const;

   /*!
        Define um novo sistema de Destiny para o fluxo
        \param DestinySys novo sistema de Destiny
    */
    void setDestiny(System* DestinySys);
    
    /*!
        Retorna sistema de Destiny
        \return sistema de Destiny
    */
    System* getDestiny() const;
};

template <typename T_FLOW>
class FlowHandle : public Handle<T_FLOW>, public Flow{

public:
    FlowHandle(const FlowHandle& flow){
        if (this == &flow){
            return;
        }

        this->pImpl_->detach();
        this->pImpl_ = flow.pImpl_;
    }

    FlowHandle& operator=(const FlowHandle& flow){
        if(this == &flow){
            return *this;
        }
    
        this->pImpl_->detach();
        this->pImpl_ = flow.pImpl_;
        return *this;
    }

    FlowHandle<T_FLOW>(string name = "", System* source = NULL, System* destiny = NULL){
        this->pImpl_->setName(name);
        this->pImpl_->setSource(source);
        this->pImpl_->setDestiny(destiny);
    }
    
    virtual ~FlowHandle(){};

    double execute(){
        return this->pImpl_->execute();
    }

    string getName() const{
        return this->pImpl_->getName();
    }

    void setName(string flowName){
        this->pImpl_->setName(flowName);
    }

    System* getSource() const{
        return this->pImpl_->getSource();
    }

    void setSource(System* sourceSys){
        this->pImpl_->setSource(sourceSys);
    }

    System* getDestiny() const{
        return this->pImpl_->getDestiny();
    }

    void setDestiny(System* DestinySys){
        this->pImpl_->setDestiny(DestinySys);
    }
};

#endif