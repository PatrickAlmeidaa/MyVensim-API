#include "SystemImpl.h"

using namespace std;
SystemBody::SystemBody (const SystemBody& sys){
    if (this == &sys){
        return;
    }
    
    name = sys.getName();
    value = sys.getValue();           
}
SystemBody&SystemBody::operator=(const SystemBody& sys){
    if (this == &sys){
        return *this;
    }

    setName(sys.getName());
    setValue(sys.getValue());          

    return *this;
}
SystemBody::SystemBody(string name, double value):name(name), value(value){}
SystemBody::~SystemBody(){}

void SystemBody::setName(string sysName){
    name = sysName;
}

string SystemBody::getName() const {
    return name;
}    

void SystemBody::setValue(double sysValue){
    value = sysValue;
}

double SystemBody::getValue() const{
    return value;
}
