#include "ModelImpl.h"   
#include "SystemImpl.h" 
#include "FlowImpl.h"   

vector<Model*> ModelBody::models;

ModelBody::ModelBody (const ModelBody& model){}

ModelBody& ModelBody::operator=(const ModelBody& model){
    return *this;
}

ModelBody::ModelBody(string name, double time):name(name), time(time){}

ModelBody::~ModelBody(){  
    if(!fl.empty()){
        for (Flow* i : fl) {
            delete (i);
        }
    }
    fl.clear();

    if(!Sys.empty()){
        for (System* i : Sys) {
            delete (i);
        }
    }
    Sys.clear();
}
    
void ModelBody::execute(double time_i, double time_f){
    vector<double> aux;
    int cont;
    for (double i = time_i; i < time_f; i++){
        for (Flow* i : fl){
            aux.push_back(i->execute());
        }

        cont = 0;
        for (Flow* j : fl) {
            if (j->getSource() != NULL){
                j->getSource()->setValue(j->getSource()->getValue() - aux[cont]);
            }

            if (j->getDestiny() != NULL){
                j->getDestiny()->setValue(j->getDestiny()->getValue() + aux[cont]);
            }
            cont++;
        }

        for (ModelBody::flowIt i = initialFlows(); i != lastFlow(); ++i){
            aux.pop_back();
        }

        time++;
    }

}

System* ModelBody::createSystem(string name_s, double value_s){
    System* sys = new SystemHandle(name_s, value_s);
    addSystem(sys);
    return sys;
}

Model* ModelBody::createModel(string name_m, double time_m){
    Model* m = new ModelHandle(name_m, time_m);
    models.push_back(m);
    return m;
}

//delegando a função de criar um modelo Model para ModelBody
Model* Model::createModel(string name_m, double time_m){
    return ModelHandle::createModel(name_m, time_m);
}

ModelBody::systemIt ModelBody::initialSystems(){
    return Sys.begin();
}

ModelBody::systemIt ModelBody::lastSystems(){
    return Sys.end();
}

ModelBody::flowIt ModelBody::initialFlows(){
    return fl.begin();
} 

ModelBody::flowIt ModelBody::lastFlow(){
    return fl.end();
}  

ModelBody::modelIt ModelBody::initialModels(){
    return models.begin();
} 

ModelBody::modelIt ModelBody::lastModel(){
    return models.end();
} 

void ModelBody::addSystem(System* s){
    Sys.insert(lastSystems(), s);            
}

void ModelBody::addFlow(Flow* f){
    fl.insert(lastFlow(), f);       
}

void ModelBody::setName(string Name_m){
    name = Name_m;
}

string ModelBody::getName() const{
    return name;
}    

void ModelBody::setTime(double Time_m){
    time = Time_m;
}

double ModelBody::getTime() const{
    return time;
}    


System* ModelBody::getSystem(int i){
    return Sys[i];
}

Flow* ModelBody::getFlow(int i){
    return fl[i];
}
