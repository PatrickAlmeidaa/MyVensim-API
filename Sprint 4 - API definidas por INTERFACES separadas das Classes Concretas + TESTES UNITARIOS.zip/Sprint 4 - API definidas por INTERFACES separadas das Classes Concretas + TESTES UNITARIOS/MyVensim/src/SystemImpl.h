#ifndef SYSTEMIMPL_H
#define SYSTEMIMPL_H

#include "System.h"

using namespace std;

class SystemImpl : public System{
protected:
    string name; /*!< Nome do sistema*/
    double value; /*!< valor do sistema*/

public:
    /*!< Construtor de cópia para o sistema*/
    SystemImpl (const SystemImpl& sys);

    /*!
        Construtor padrão para System que recebe dois parametros
        \param name nome do sistema
        \param value valor inicial que o sistema recebe
        \return objeto de SystemImpl que será usado em Flow e Model
    */
    SystemImpl(string name = "", double value = 0.0);

    /*!< Sobrecarga do operador igual*/
    SystemImpl& operator=(const SystemImpl& sys);

    /*!< Destrutor padão para o sistema*/
    virtual ~SystemImpl();

    /*!
        Define um novo nome para o sistema
        \param sysName novo nome do sistema
    */
    void setName(string sysName); 

    /*!
        Retorna o nome do sistema
        \return nome do sistema
    */
    string getName() const;

    /*!
        Define um novo valor para o sistema
        \param sysValue novo valor do sistema
    */
    void setValue(double sysValue);

    /*!
        Retorna o valor do sistema
        \return valor do sistema
    */
    double getValue() const;

};
#endif