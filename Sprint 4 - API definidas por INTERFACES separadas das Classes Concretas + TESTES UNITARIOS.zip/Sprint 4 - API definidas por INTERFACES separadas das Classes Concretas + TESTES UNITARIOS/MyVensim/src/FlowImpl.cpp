#include "FlowImpl.h"

FlowImpl::FlowImpl (const FlowImpl& f){
    if (this == &f){
        return;
    }
    
    name = f.getName();
    Source = f.getSource();
    Dest = f.getDest();
}

FlowImpl::FlowImpl(string name, System* Source, System* Dest):name(name), Source(Source), Dest(Dest){}

FlowImpl::~FlowImpl(){}

string FlowImpl::getName() const {
    return name;
}
        
void FlowImpl::setName(string Name_f){
    name = Name_f;
}

System* FlowImpl::getSource() const{
    return Source; 
}

void FlowImpl::setSource(System* SourceSys){
    Source = SourceSys;
}

System* FlowImpl::getDest() const {
    return Dest;
}

void FlowImpl::setDest(System* DestSys) {
    Dest = DestSys;
}

FlowImpl& FlowImpl::operator=(const Flow& f){
    if (this == &f){
        return *this;
    }

    setName(f.getName());
    setSource(NULL);
    setDest(NULL);

    return *this;
}