#ifndef MODELIMPL_H
#define MODELIMPL_H

#include "Model.h"

using namespace std;

class ModelImpl : public Model{
protected:
    string name; /*!< Nome do modelo*/
    double time; /*!< Tempo que o modelo executará*/
    vector<System*> Sys; /*!< container para armazenar os sistemas do modelo*/
    vector<Flow*> fl; /*!< container para armazenar os fluxos do modelo*/

public:             
    typedef vector<System *>::iterator systemIt;
    typedef vector<Flow *>::iterator flowIt;

    /*!< Retorna o interador inicial do container de systemas*/
    systemIt initialSystems();

    /*!< Retorna o interador final do container de systemas*/
    systemIt lastSystems();

    /*!< Retorna o interador inicial do container de fluxos*/
    flowIt initialFlows();

    /*!< Retorna o interador final do container de fluxos*/
    flowIt lastFlow();


    /*!
        Construtor padrão para Model que recebe dois parametros
        \param name nome do modelo
        \param time valor inicial que o modelo recebe
        \return objeto de ModelImpl
    */
    ModelImpl(string name="", double time=0.0);

    /*!< destrutor para o modelo*/
    virtual ~ModelImpl();

    /*!
        Roda todos os fluxos presentes no modelo com suas respectivar operações internas
        \param time_i tempo inicial
        \param time_f tempo final
    */
    void execute(double time_i=0.0, double time_f=0.0);

    /*!
        Adiciona um sistema ao modelo
        \param s sistema que será adicionado
    */
    void addSystem(System* s);

    /*!
        Adiciona um fluxo ao modelo
        \param f fluxo que será adicionado
    */
    void addFlow(Flow* f);

    /*!
        Define um novo nome para o modelo
        \param Name_m novo nome do modelo
    */
    void setName(string Name_m);

    /*!
        Retorna o nome do modelo
        \return nome do modelo
    */
    string getName() const;

    /*!
        Define um novo tempo de execução para o modelo
        \param Time_m novo tempo de execução
    */
    void setTime(double Time_m);

    /*!
        Retorna o tempo de execução
        \return tempo de execução
    */
    double getTime() const;

    /*!
        Retorna um determinado sistema que está presente no modelo
        \param i posição do container na qual o sistema desejado se encontra
        \return sistema desejado
    */
    System* getSystem(int i);

    /*!
        Retorna um determinado fluxo que está presente no modelo
        \param i posição do container na qual o fluxo desejado se encontra
        \return fluxo desejado
    */
    Flow* getFlow(int i);

private:
    /*!< sobrecarga do operador igual*/
    ModelImpl& operator=(const ModelImpl& model);

    /*!< Construtor de cópia*/
    ModelImpl (const ModelImpl& model);
};

#endif