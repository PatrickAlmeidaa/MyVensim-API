#include "ModelImpl.h"   
#include "SystemImpl.h" 
#include "FlowImpl.h"   

ModelImpl::ModelImpl (const ModelImpl& model){}

ModelImpl& ModelImpl::operator=(const ModelImpl& model){
    return *this;
}

ModelImpl::ModelImpl(string name, double time):name(name), time(time){}

ModelImpl::~ModelImpl(){           
    fl.clear();

    Sys.clear();
}
    
void ModelImpl::execute(double time_i, double time_f){
    vector<double> aux;
    int cont;
    for (double i = time_i; i < time_f; i++){
        for (Flow* i : fl){
            aux.push_back(i->execute());
        }

        cont = 0;
        for (Flow* j : fl) {
            if (j->getSource() != NULL){
                j->getSource()->setValue(j->getSource()->getValue() - aux[cont]);
            }

            if (j->getDest() != NULL){
                j->getDest()->setValue(j->getDest()->getValue() + aux[cont]);
            }
            cont++;
        }

        for (ModelImpl::flowIt i = initialFlows(); i != lastFlow(); ++i){
            aux.pop_back();
        }

        time++;
    }

}

ModelImpl::systemIt ModelImpl::initialSystems(){
    return Sys.begin();
}

ModelImpl::systemIt ModelImpl::lastSystems(){
    return Sys.end();
}

ModelImpl::flowIt ModelImpl::initialFlows(){
    return fl.begin();
} 

ModelImpl::flowIt ModelImpl::lastFlow(){
    return fl.end();
}  

void ModelImpl::addSystem(System* s){
    Sys.insert(lastSystems(), s);            
}

void ModelImpl::addFlow(Flow* f){
    fl.insert(lastFlow(), f);       
}

void ModelImpl::setName(string Name_m){
    name = Name_m;
}

string ModelImpl::getName() const{
    return name;
}    

void ModelImpl::setTime(double Time_m){
    time = Time_m;
}

double ModelImpl::getTime() const{
    return time;
}    


System* ModelImpl::getSystem(int i){
    return Sys[i];
}

Flow* ModelImpl::getFlow(int i){
    return fl[i];
}
