#ifndef FLOW_H
#define FLOW_H

#include<string>

class System;
using namespace std;

class Flow{
public: 
    virtual ~Flow(){}

    virtual double execute() = 0;

    virtual string getName() const = 0;
    virtual void setName(string flowName) = 0;

    virtual System* getSource() const = 0;
    virtual void setSource(System* sourceSys) = 0;

    virtual System* getDest() const = 0;
    virtual void setDest(System* DestSys) = 0;
};
#endif