#ifndef MODEL_H
#define MODEL_H

#include <vector>
#include <string>

class Flow;
class System;

using namespace std;

class Model{
public:        
    typedef vector<System*>::iterator systemIt;
    typedef vector<Flow*>::iterator flowIt;
    
    virtual systemIt initialSystems() = 0;
    virtual systemIt lastSystems() = 0; 
    virtual flowIt   initialFlows() = 0; 
    virtual flowIt   lastFlow() = 0;

    virtual ~Model(){}

    virtual void execute(double start, double final) = 0;

    virtual void addSystem(System* sys) = 0;
    virtual void addFlow(Flow* flow) = 0;

    virtual void setName(string modelName) = 0;
    virtual string getName() const = 0;

    virtual void setTime(double currentTime) = 0;
    virtual double getTime() const = 0;

    virtual System* getSystem(int i) = 0;
    virtual Flow* getFlow(int i) = 0;
};
#endif