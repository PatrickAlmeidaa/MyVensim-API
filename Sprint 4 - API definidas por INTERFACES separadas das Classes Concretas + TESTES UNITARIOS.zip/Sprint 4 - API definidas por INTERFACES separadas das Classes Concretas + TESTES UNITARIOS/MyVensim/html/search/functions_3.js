var searchData=
[
  ['flowimpl_0',['FlowImpl',['../class_flow_impl.html#aef142b4af715fb4f2f3460c7104804e8',1,'FlowImpl::FlowImpl(const FlowImpl &amp;f)'],['../class_flow_impl.html#af3a688ffcc172f6a792836be5eb93fae',1,'FlowImpl::FlowImpl(string name=&quot;&quot;, System *Source=NULL, System *Dest=NULL)']]]
];
