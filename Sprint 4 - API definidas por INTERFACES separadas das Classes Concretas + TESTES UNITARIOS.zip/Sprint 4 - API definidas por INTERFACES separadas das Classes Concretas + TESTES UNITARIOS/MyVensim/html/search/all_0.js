var searchData=
[
  ['addflow_0',['addFlow',['../class_model.html#a57910e9a0f2cf41862da928e3edcf974',1,'Model::addFlow()'],['../class_model_impl.html#a0414b01f601e6b466d03c84ef2b18dc4',1,'ModelImpl::addFlow()']]],
  ['addsystem_1',['addSystem',['../class_model.html#acd061f250357f4b6c5232c0bc7dcd82d',1,'Model::addSystem()'],['../class_model_impl.html#a7baffb369cf0b2c42a1c6738196b79a9',1,'ModelImpl::addSystem()']]]
];
