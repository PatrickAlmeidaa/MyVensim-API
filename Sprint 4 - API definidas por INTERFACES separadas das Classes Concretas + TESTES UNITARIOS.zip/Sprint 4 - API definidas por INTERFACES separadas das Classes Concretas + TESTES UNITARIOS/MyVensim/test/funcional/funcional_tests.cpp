#include <iostream>
#include <assert.h>
#include<math.h>
#include "funcional_tests.h" 
#include "../../src/ModelImpl.h"

using namespace std;

void exponentialFuncionalTest(){
    System* pop1 = new SystemImpl("P1", 100);
    System* pop2 = new SystemImpl("P2", 0);
    Flow* f= new Exponencial("test", pop1, pop2);
    Model* m = new ModelImpl("Exponential test", 0.0);

    m->addSystem(pop1);
    m->addSystem(pop2);
    m->addFlow(f);

    assert(pop1->getName() == "P1");
    assert(pop2->getName() == "P2");
    assert(f->getName() == "test");
    assert(m->getName() == "Exponential test");

    assert(fabs(pop1->getValue() - 100.0) < 0.0001);
    assert(fabs(pop2->getValue() - 0.0) < 0.0001);
    assert(fabs(m->getTime() - 0.0) < 0.0001);

    m->execute(0, 100);

    assert(fabs(pop1->getValue() - 36.6032) < 0.0001);
    assert(fabs(pop2->getValue() - 63.3968) < 0.0001);
    assert(fabs(m->getTime() - 100.0) < 0.0001);

    delete (m);
    cout << "Teste exponential rolou" << endl;
}

void logisticalFuncionalTest(){
    System* p1 = new SystemImpl("P1", 100);
    System* p2 = new SystemImpl("P2", 10);
    Flow* f = new Logistic("test", p1, p2);
    Model* m = new ModelImpl("Logistic test", 0.0);

    m->addSystem(p1);
    m->addSystem(p2);
    m->addFlow(f);

    assert(p1->getName() == "P1");
    assert(p2->getName() == "P2");
    assert(f->getName() == "test");
    assert(m->getName() == "Logistic test");

    assert(fabs(p1->getValue() - 100.0) < 0.0001);
    assert(fabs(p2->getValue() - 10.0) < 0.0001);
    assert(fabs(m->getTime() - 0.0) < 0.0001);

    m->execute(0, 100);

    assert(fabs(p1->getValue() - 88.2167) < 0.0001);
    assert(fabs(p2->getValue() - 21.7833) < 0.0001);
    assert(fabs(m->getTime() - 100.0) < 0.0001);

    delete(m);
    cout << "Teste logistical rolou" << endl;
}

void complexFuncionalTest(){
    System* q1 = new SystemImpl("Q1", 100);
    System* q2 = new SystemImpl("Q2", 0);
    System* q3 = new SystemImpl("Q3", 100);
    System* q4 = new SystemImpl("Q4", 0);
    System* q5 = new SystemImpl("Q5", 0);
    Flow* f_f = new Complex("f", q1, q2);
    Flow* f_t = new Complex("t", q2, q3);
    Flow* f_u = new Complex("u", q3, q4);
    Flow* f_v = new Complex("v", q4, q1);
    Flow* f_g = new Complex("g", q1, q3);
    Flow* f_r = new Complex("r", q2, q5);
    Model* m = new ModelImpl("Complex test", 0.0);

    m->addSystem(q1);
    m->addSystem(q2);
    m->addSystem(q3);
    m->addSystem(q4);
    m->addSystem(q5);
    m->addFlow(f_f);
    m->addFlow(f_t);
    m->addFlow(f_u);
    m->addFlow(f_v);
    m->addFlow(f_g);
    m->addFlow(f_r);

    assert(q1->getName() == "Q1");
    assert(q2->getName() == "Q2");
    assert(q3->getName() == "Q3");
    assert(q4->getName() == "Q4");
    assert(q5->getName() == "Q5");
    assert(f_f->getName() == "f");
    assert(f_t->getName() == "t");
    assert(f_u->getName() == "u");
    assert(f_v->getName() == "v");
    assert(f_g->getName() == "g");
    assert(f_r->getName() == "r");
    assert(m->getName() == "Complex test");

    assert(fabs(q1->getValue() - 100.0) < 0.0001);
    assert(fabs(q2->getValue() - 0.0) < 0.0001);
    assert(fabs(q3->getValue() - 100.0) < 0.0001);
    assert(fabs(q4->getValue() - 0.0) < 0.0001);
    assert(fabs(q5->getValue() - 0.0) < 0.0001);
    assert(fabs(m->getTime() - 0.0) < 0.0001);

    m->execute(0, 100);

    assert(fabs(q1->getValue() - 31.8513) < 0.0001);
    assert(fabs(q2->getValue() - 18.4003) < 0.0001);
    assert(fabs(q3->getValue() - 77.1143) < 0.0001);
    assert(fabs(q4->getValue() - 56.1728) < 0.0001);
    assert(fabs(q5->getValue() - 16.4612) < 0.0001);
    assert(fabs(m->getTime() - 100.0) < 0.0001);

    delete(m);
    cout << "Teste complex rolou" << endl;
}