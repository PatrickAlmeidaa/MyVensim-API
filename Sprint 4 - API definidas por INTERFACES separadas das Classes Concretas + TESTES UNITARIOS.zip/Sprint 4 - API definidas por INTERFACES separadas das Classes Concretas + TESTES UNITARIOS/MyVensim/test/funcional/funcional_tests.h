#ifndef FUNCTIONAL_TEST
#define FUNCTIONAL_TEST

#include "../../src/SystemImpl.h"
#include "../../src/FlowImpl.h"

class Exponencial : public FlowImpl{
public:
    /*!
        Construtor para Exponencial que recebe três parametros
        \param name nome do teste
        \param Source sistema de origem do teste
        \param Dest sistema de destino teste
    */
    Exponencial(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    /*!
        implementação da função com a operação qeu rege o teste exponencial
        \return valor do fluxo 
    */
    double execute(){
        return 0.01 * getSource()->getValue();
    }
};

class Logistic : public FlowImpl{
public:
    /*!
        Construtor para Logistic que recebe três parametros
        \param name nome do teste
        \param Source sistema de origem do teste
        \param Dest sistema de destino teste
    */
    Logistic(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    /*!
        implementação da função com a operação que rege o teste de logística
        \return valor do fluxo 
    */
    double execute(){
        return 0.01 * getDest()->getValue() * (1 - getDest()->getValue() / 70);
    }
};

class Complex : public FlowImpl{
public:
    /*!
        Construtor para Complex  que recebe três parametros
        \param name nome do teste
        \param Source sistema de origem do teste
        \param Dest sistema de destino teste
    */
    Complex(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    /*!
        implementação da função com a operação qeu rege o teste complexo
        \return valor do fluxo 
    */
    double execute(){
        return 0.01 * getSource()->getValue();
    }
};
#endif

/*!< Função que roda o teste exponencial */
void exponentialFuncionalTest();

/*!< Função qeu roda o teste de logística*/
void logisticalFuncionalTest();

/*!< Função que roda o teste complexo*/
void complexFuncionalTest();