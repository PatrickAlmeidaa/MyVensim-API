#include "../../src/SystemImpl.h"
#include "unit_system.h"
#include <assert.h>

using namespace std;

void unit_System_constructor(){
    System *aux_temp = new SystemImpl("p1", 100.0);
    assert(aux_temp->getName() == "p1");
    assert(aux_temp->getValue() == 100.0);
}
void unit_System_destructor(){ }

void unit_System_setName(){
    System *s = new SystemImpl();
    s->setName("p1");
    assert(s->getName() == "p1");
}
void unit_System_setValue(){
    System *s = new SystemImpl();
    s->setValue(10.0);
    assert(s->getValue() == 10.0);
}

void unit_System_getName(){
    System *s = new SystemImpl("p1", 10.0);
    assert(s->getName() == "p1");
}
void unit_System_getValue(){
    System *s = new SystemImpl("p1", 10.0);
    assert(s->getValue() == 10.0);
}

void unit_System_operator(){
    System *aux_temp = new SystemImpl("p1", 100.0);
    System *s_test;

    s_test = aux_temp;

    assert(s_test->getValue() == 100.0);
    assert(s_test->getName() == "p1");
}

void run_unit_tests_System(){
    unit_System_constructor();
    unit_System_destructor();

    unit_System_setName();
    unit_System_setValue();

    unit_System_getName();
    unit_System_getValue();

    unit_System_operator();
}