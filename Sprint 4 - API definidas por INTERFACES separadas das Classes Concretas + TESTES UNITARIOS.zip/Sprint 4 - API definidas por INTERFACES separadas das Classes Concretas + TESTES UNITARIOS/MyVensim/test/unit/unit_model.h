#ifndef MYVENSIM_UNIT_MODEL_H
#define MYVENSIM_UNIT_MODEL_H

void unit_Model_constructor();
void unit_Model_destructor();

void unit_Model_setName();
void unit_Model_setTime();

void unit_Model_getName();
void unit_Model_getTime();
void unit_Model_getSystem();
void unit_Model_getFlow();

void unit_Model_execure();
void unit_Model_addSystem();
void unit_Model_addFlow();

void unit_Model_operator();

void run_unit_tests_Model();

#endif
