#include "../../src/FlowImpl.h"
#include "../../src/SystemImpl.h"
#include "unit_flow.h"
#include <assert.h>

class Unit : public FlowImpl{
public:
    Unit(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    double execute(){
        return 1 + getSource()->getValue();
    }
};

void unit_Flow_constructor(){
    System *sys1 = new SystemImpl("s1", 10.0);
    System *sys2 = new SystemImpl("s2", 10.0);

    Flow *aux_temp2 = new Unit("test 1", sys1, sys2);

    assert(aux_temp2->getName() == "test 1");
    assert(aux_temp2->getSource() == sys1);
    assert(aux_temp2->getDest() == sys2);
}

void unit_Flow_destructor(){ }

void unit_Flow_setName(){
    Flow *aux_temp2 = new Unit("", NULL, NULL);
    aux_temp2->setName("test set name");

    assert(aux_temp2->getName() == "test set name");
}

void unit_Flow_setDest(){
    System *sys2 = new SystemImpl("s2", 100.0);

    Flow *aux_temp2 = new Unit("test set dest", NULL, sys2);
    aux_temp2->setDest(sys2);

    assert(aux_temp2->getDest() == sys2);
}

void unit_Flow_setSource(){
    System *sys = new SystemImpl("s2", 100.0);

    Flow *aux_temp2 = new Unit("test set source", sys, NULL);
    aux_temp2->setDest(sys);

    assert(aux_temp2->getDest() == sys);
}

void unit_Flow_getName(){
    Flow *aux_temp2 = new Unit("test get name", NULL, NULL);

    assert(aux_temp2->getName() == "test get name");
}

void unit_Flow_getDest(){
    System *sys2 = new SystemImpl("s2", 10.0); 

    Flow *aux_temp2 = new Unit("test get dest", NULL, sys2);

    assert(aux_temp2->getDest() == sys2);
}

void unit_Flow_getSource(){
    System *sys = new SystemImpl("s2", 10.0); 

    Flow *aux_temp2 = new Unit("test get source", sys, NULL);

    assert(aux_temp2->getSource() == sys);
}

void unit_Flow_operator(){
    System *sys1 = new SystemImpl("s1", 10.0);
    System *sys2 = new SystemImpl("s2", 10.0);

    Flow *aux_temp2 = new Unit("test op", sys1, sys2);
    Flow *test;

    test = aux_temp2;

    assert(test->getName() == "test op");
    assert(test->getSource() == sys1);
    assert(test->getDest() == sys2);
}

void run_unit_tests_Flow(){
    unit_Flow_constructor();
    unit_Flow_destructor();

    unit_Flow_setName();
    unit_Flow_setDest();
    unit_Flow_setSource();

    unit_Flow_getName();
    unit_Flow_getDest();
    unit_Flow_getSource();

    unit_Flow_operator();
}