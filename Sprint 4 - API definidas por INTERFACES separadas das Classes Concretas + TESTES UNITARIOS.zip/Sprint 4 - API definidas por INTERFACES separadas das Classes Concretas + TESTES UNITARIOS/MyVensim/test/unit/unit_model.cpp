#include "unit_model.h"
#include <assert.h>
#include <math.h>
#include "../../src/FlowImpl.h"
#include "../../src/SystemImpl.h"
#include "../../src/ModelImpl.h"

class UnitM : public FlowImpl{
public:
    UnitM(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    double execute(){
        return 0.01 * getSource()->getValue();
    }
};

void unit_Model_constructor(){
    System* pop1 = new SystemImpl("P1", 100);
    System* pop2 = new SystemImpl("P2", 0);
    UnitM* f = new UnitM("test", pop1, pop2);
    Model *m = new ModelImpl("test constructor", 100.0);

    m->addSystem(pop1);
    m->addSystem(pop2);
    m->addFlow(f);

    assert(m->getName() == "test constructor");
    assert(m->getTime() == 100.0);
    assert(m->getSystem(0) == pop1);
    assert(m->getSystem(1) == pop2);
    assert(m->getFlow(0) == f);
}
void unit_Model_destructor(){}

void unit_Model_setName(){
    Model *m = new ModelImpl("", 100.0);

    m->setName("set name test");

    assert(m->getName() == "set name test");
}
void unit_Model_setTime(){
    Model *m = new ModelImpl("test", 0.0);
    
    m->setTime(50.0);

    assert(m->getTime() == 50.0);
}

void unit_Model_getName(){
    Model *m = new ModelImpl("get name test", 100.0);

    assert(m->getName() == "get name test");
}
void unit_Model_getTime(){
    Model *m = new ModelImpl("test", 50.0);

    assert(m->getTime() == 50.0);
}
void unit_Model_getSystem(){
    System* pop1 = new SystemImpl("P1", 100);
    System* pop2 = new SystemImpl("P2", 0);
    Model *m = new ModelImpl("test get system", 100.0);

    m->addSystem(pop1);
    m->addSystem(pop2);

    assert(m->getSystem(0) == pop1);
    assert(m->getSystem(1) == pop2);
}
void unit_Model_getFlow(){
    UnitM* f = new UnitM("test", NULL, NULL);
    Model *m = new ModelImpl("test get flow", 100.0);

    m->addFlow(f);

    assert(m->getFlow(0) == f);
}

void unit_Model_execure(){
    System* pop1 = new SystemImpl("P1", 100);
    System* pop2 = new SystemImpl("P2", 0);
    UnitM* f = new UnitM("test", pop1, pop2);
    Model *m = new ModelImpl("test execute", 0.0);

    m->addSystem(pop1);
    m->addSystem(pop2);
    m->addFlow(f);

    m->execute(0, 100);

    assert(fabs(pop1->getValue() - 36.6032) < 0.0001);
    assert(fabs(pop2->getValue() - 63.3968) < 0.0001);
}
void unit_Model_addSystem(){
    System* pop1 = new SystemImpl("P1", 100);
    System* pop2 = new SystemImpl("P2", 0);
    Model *m = new ModelImpl("test add system", 100.0);

    m->addSystem(pop1);
    m->addSystem(pop2);

    assert(m->getSystem(0) == pop1);
    assert(m->getSystem(1) == pop2);
}
void unit_Model_addFlow(){
    UnitM* f = new UnitM("test", NULL, NULL);
    Model *m = new ModelImpl("test add flow", 100.0);

    m->addFlow(f);

    assert(m->getFlow(0) == f);
}

void unit_Model_operator(){
    System* pop1 = new SystemImpl("P1", 100);
    System* pop2 = new SystemImpl("P2", 0);
    UnitM* f = new UnitM("test", pop1, pop2);
    Model *m = new ModelImpl("test operator", 100.0);
    Model *test;

    m->addSystem(pop1);
    m->addSystem(pop2);
    m->addFlow(f);

    test = m;

    assert(test->getName() == "test operator");
    assert(test->getSystem(0) == pop1);
    assert(test->getSystem(1) == pop2);
    assert(test->getFlow(0) == f);
}

void run_unit_tests_Model(){
    unit_Model_constructor();
    unit_Model_destructor();

    unit_Model_setName();
    unit_Model_setTime();

    unit_Model_getName();
    unit_Model_getTime();
    unit_Model_getSystem();
    unit_Model_getFlow();

    unit_Model_execure();
    unit_Model_addSystem();
    unit_Model_addFlow();

    unit_Model_operator();
}