#include "unit_flow.h"
#include "unit_model.h"
#include "unit_system.h"
#include "unit_tests.h"
#include <iostream>

using namespace std;

void run_unit_tests_globals(){
    run_unit_tests_Model();
    cout << "---Model OK---" << endl;
    run_unit_tests_Flow();
    cout << "---Flow OK---" << endl;
    run_unit_tests_System();
    cout << "---System OK---" << endl;
}