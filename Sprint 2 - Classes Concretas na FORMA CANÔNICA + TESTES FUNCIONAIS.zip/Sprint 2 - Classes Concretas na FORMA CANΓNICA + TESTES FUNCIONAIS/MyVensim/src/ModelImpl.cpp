#include "./ModelImpl.h"      

ModelImpl::ModelImpl (const ModelImpl& model){}

void ModelImpl::operator=(const ModelImpl& model){}

ModelImpl::ModelImpl(string name, double time):name(name), time(time){}

ModelImpl::~ModelImpl(){           
    for (Flow* i : fl) {
        delete (i);
    }
    fl.clear();

    for (System* i : Sys) {
        delete (i);
    }
    Sys.clear();
}
    
void ModelImpl::execute(double time_i, double time_f){
    vector<double> aux;
    int cont;
    for (double i = time_i; i < time_f; i++){
        for (Flow* i : fl){
            aux.push_back(i->execute());
        }

        cont = 0;
        for (Flow* j : fl) {
            if (j->getSource() != NULL){
                j->getSource()->setValue(j->getSource()->getValue() - aux[cont]);
            }

            if (j->getDest() != NULL){
                j->getDest()->setValue(j->getDest()->getValue() + aux[cont]);
            }
            cont++;
        }

        for (ModelImpl::flowIt i = initialFlows(); i != lastFlow(); ++i){
            aux.pop_back();
        }

        time++;
    }

}

ModelImpl::systemIt ModelImpl::initialSystems(){
    return Sys.begin();
}

ModelImpl::systemIt ModelImpl::lastSystems(){
    return Sys.end();
}

ModelImpl::flowIt ModelImpl::initialFlows(){
    return fl.begin();
} 

ModelImpl::flowIt ModelImpl::lastFlow(){
    return fl.end();
}  

void ModelImpl::addSystem(System* s){
    Sys.insert(lastSystems(), s);            
}

void ModelImpl::addFlow(Flow* f){
    fl.insert(lastFlow(), f);       
}

void ModelImpl::setName(string modelName){
    name = modelName;
}

string ModelImpl::getName() const{
    return name;
}    

void ModelImpl::setTime(double currentTime){
    time = currentTime;
}

double ModelImpl::getTime() const{
    return time;
}    


System* ModelImpl::getSystem(int i){
    return Sys[i];
}

Flow* ModelImpl::getFlow(int i){
    return fl[i];
}
