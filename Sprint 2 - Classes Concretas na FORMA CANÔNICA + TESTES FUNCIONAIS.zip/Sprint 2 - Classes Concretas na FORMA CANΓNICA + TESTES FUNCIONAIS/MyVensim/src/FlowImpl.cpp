#include "FlowImpl.h"

FlowImpl::FlowImpl(string name, System* Source, System* Dest):name(name), Source(Source), Dest(Dest){}

FlowImpl::~FlowImpl(){}

string FlowImpl::getName() const {
    return name;
}
        
void FlowImpl::setName(string flowName){
    name = flowName;
}

System* FlowImpl::getSource() const{
    return Source; 
}

void FlowImpl::setSource(System* SourceSys){
    Source = SourceSys;
}

System* FlowImpl::getDest() const {
    return Dest;
}

void FlowImpl::setDest(System* DestSys) {
    Dest = DestSys;
}

FlowImpl& FlowImpl::operator=(const Flow& flow){
    if (this == &flow){
        return *this;
    }

    setName(flow.getName());
    setSource(NULL);
    setDest(NULL);

    return *this;
}