#ifndef FLOWIMPL_H
#define FLOWIMPL_H

#include "./Flow.h"

using namespace std;

class FlowImpl : public Flow{
protected:
    string name;
    System* Source;
    System* Dest;

public:
    friend class Model;
    friend class ModelImpl;

    FlowImpl(string name = "", System* Source = NULL, System* Dest = NULL);

    virtual ~FlowImpl();

    virtual double execute() = 0;

    string getName() const;

    void setName(string flowName);

    System* getSource() const;

    void setSource(System* SourceSys);

    System* getDest() const;

    void setDest(System* DestSys);

    FlowImpl& operator=(const Flow& flow);
};

#endif