#ifndef FUNCTIONAL_TEST
#define FUNCTIONAL_TEST

#include "../../src/SystemImpl.h"
#include "../../src/FlowImpl.h"

void exponentialFuncionalTest();

void logisticalFuncionalTest();

void complexFuncionalTest();

class Exponencial : public FlowImpl{
public:
    Exponencial(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    double execute(){
        return 0.01 * getSource()->getValue();
    }
};

class Logistic : public FlowImpl{
public:
    Logistic(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    double execute(){
        return 0.01 * getDest()->getValue() * (1 - getDest()->getValue() / 70);
    }
};

class Complex : public FlowImpl{
public:
    Complex(string name, System* source, System* Dest): FlowImpl(name, source, Dest){}

    double execute(){
        return 0.01 * getSource()->getValue();
    }
};
#endif