#ifndef FLOW_H
#define FLOW_H

#include<string> //fazer uma referencia a string para não chamar a biblioteca aqui

class System;
using namespace std;

class Flow{
public: 
    /*!< Destrutor*/
    virtual ~Flow(){}

    /*!
        Função responsável por executar as operações de fluxo definidas pelo usuário. 
    */
    virtual double execute() = 0;

    /*!
        Retorna o nome do fluxo
        \return nome do fluxo
    */
    virtual string getName() const = 0;

    /*!
        Define um novo nome para o fluxo
        \param Name_f novo nome do fluxo
    */
    virtual void setName(string Name_f) = 0;

    /*!
        Retorna sistema de origem
        \return sistema de origem
    */
    virtual System* getSource() const = 0;

    /*!
        Define um novo sistema de origem para o fluxo
        \param SourceSys novo sistema de origem
    */
    virtual void setSource(System* sourceSys) = 0;

    /*!
        Retorna sistema de destino
        \return sistema de destino
    */
    virtual System* getDestiny() const = 0;

    /*!
        Define um novo sistema de destino para o fluxo
        \param DestinySys novo sistema de destino
    */
    virtual void setDestiny(System* DestinySys) = 0;
};
#endif