#ifndef FLOWIMPL_H
#define FLOWIMPL_H

#include "Flow.h"

using namespace std;

class FlowImpl : public Flow{
protected:
    string name; /*!< Nome do fluxo*/
    System* Source; /*!< Sistema de origem do fluxo*/
    System* Destiny; /*!< Sistema de Destiny do fluxo*/

public:
    /*!< Construtor de cópia para o fluxo*/
    FlowImpl (const FlowImpl& f);

    /*!
        Construtor padrão para Flow que recebe três parametros
        \param name nome do fluxo
        \param Source sistema de origem do fluxo
        \param Destiny sistema de Destiny fluxo
        \return objeto de FlowImpl que será usado em Model
    */
    FlowImpl(string name = "", System* Source = NULL, System* Destiny = NULL);

    /*!< Sobrecarga do operadorde igual*/
    FlowImpl& operator=(const Flow& f);
    
    /*!< Destrutor padão para o fluxo*/
    virtual ~FlowImpl();
    
    /*!
        Função responsável por executar as operações de fluxo definidas pelo usuário. 
        A definição das operaçoes de fluxo deverão ser feitas por meio de subclasses.
    */
    virtual double execute() = 0;

    /*!
        Define um novo nome para o fluxo
        \param Name_f novo nome do fluxo
    */
    void setName(string Name_f);
   
    /*!
        Retorna o nome do fluxo
        \return nome do fluxo
    */
    string getName() const;

    /*!
        Define um novo sistema de origem para o fluxo
        \param SourceSys novo sistema de origem
    */
    void setSource(System* SourceSys);
   
   /*!
        Retorna sistema de origem
        \return sistema de origem
    */
    System* getSource() const;

   /*!
        Define um novo sistema de Destiny para o fluxo
        \param DestinySys novo sistema de Destiny
    */
    void setDestiny(System* DestinySys);
    
    /*!
        Retorna sistema de Destiny
        \return sistema de Destiny
    */
    System* getDestiny() const;
};

#endif