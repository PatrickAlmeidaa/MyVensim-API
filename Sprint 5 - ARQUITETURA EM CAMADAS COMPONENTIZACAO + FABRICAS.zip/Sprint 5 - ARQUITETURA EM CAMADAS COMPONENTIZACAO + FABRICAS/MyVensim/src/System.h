#ifndef STOCK_H
#define STOCK_H

#include <string>

using namespace std;

class System{
public:
    /*!< Destrutor*/
    virtual ~System(){}

    /*!
        Define um novo nome para o sistema
        \param sysName novo nome do sistema
    */
    virtual void setName(string sysName) = 0;

    /*!
        Retorna o nome do sistema
        \return nome do sistema
    */
    virtual string getName() const = 0;
    
    /*!
        Define um novo valor para o sistema
        \param sysValue novo valor do sistema
    */
    virtual void setValue(double sysValue) = 0;

    /*!
        Retorna o valor do sistema
        \return valor do sistema
    */
    virtual double getValue() const = 0;
};
#endif