#include "ModelImpl.h"   
#include "SystemImpl.h" 
#include "FlowImpl.h"   

vector<Model*> ModelImpl::models;

ModelImpl::ModelImpl (const ModelImpl& model){}

ModelImpl& ModelImpl::operator=(const ModelImpl& model){
    return *this;
}

ModelImpl::ModelImpl(string name, double time):name(name), time(time){}

ModelImpl::~ModelImpl(){           
    fl.clear();

    Sys.clear();
}
    
void ModelImpl::execute(double time_i, double time_f){
    vector<double> aux;
    int cont;
    for (double i = time_i; i < time_f; i++){
        for (Flow* i : fl){
            aux.push_back(i->execute());
        }

        cont = 0;
        for (Flow* j : fl) {
            if (j->getSource() != NULL){
                j->getSource()->setValue(j->getSource()->getValue() - aux[cont]);
            }

            if (j->getDestiny() != NULL){
                j->getDestiny()->setValue(j->getDestiny()->getValue() + aux[cont]);
            }
            cont++;
        }

        for (ModelImpl::flowIt i = initialFlows(); i != lastFlow(); ++i){
            aux.pop_back();
        }

        time++;
    }

}

System* ModelImpl::createSystem(string name_s, double value_s){
    System* sys = new SystemImpl(name_s, value_s);
    addSystem(sys);
    return sys;
}

Model* ModelImpl::createModel(string name_m, double time_m){
    Model* m = new ModelImpl(name_m, time_m);
    models.push_back(m);
    return m;
}

//delegando a função de criar um modelo Model para ModelImpl
Model* Model::createModel(string name_m, double time_m){
    return ModelImpl::createModel(name_m, time_m);
}

ModelImpl::systemIt ModelImpl::initialSystems(){
    return Sys.begin();
}

ModelImpl::systemIt ModelImpl::lastSystems(){
    return Sys.end();
}

ModelImpl::flowIt ModelImpl::initialFlows(){
    return fl.begin();
} 

ModelImpl::flowIt ModelImpl::lastFlow(){
    return fl.end();
}  

ModelImpl::modelIt ModelImpl::initialModels(){
    return models.begin();
} 

ModelImpl::modelIt ModelImpl::lastModel(){
    return models.end();
} 

void ModelImpl::addSystem(System* s){
    Sys.insert(lastSystems(), s);            
}

void ModelImpl::addFlow(Flow* f){
    fl.insert(lastFlow(), f);       
}

void ModelImpl::setName(string Name_m){
    name = Name_m;
}

string ModelImpl::getName() const{
    return name;
}    

void ModelImpl::setTime(double Time_m){
    time = Time_m;
}

double ModelImpl::getTime() const{
    return time;
}    


System* ModelImpl::getSystem(int i){
    return Sys[i];
}

Flow* ModelImpl::getFlow(int i){
    return fl[i];
}
