#include "FlowImpl.h"

FlowImpl::FlowImpl (const FlowImpl& f){
    if (this == &f){
        return;
    }
    
    name = f.getName();
    Source = f.getSource();
    Destiny = f.getDestiny();
}

FlowImpl::FlowImpl(string name, System* Source, System* Destiny):name(name), Source(Source), Destiny(Destiny){}

FlowImpl::~FlowImpl(){}

string FlowImpl::getName() const {
    return name;
}
        
void FlowImpl::setName(string Name_f){
    name = Name_f;
}

System* FlowImpl::getSource() const{
    return Source; 
}

void FlowImpl::setSource(System* SourceSys){
    Source = SourceSys;
}

System* FlowImpl::getDestiny() const {
    return Destiny;
}

void FlowImpl::setDestiny(System* DestinySys) {
    Destiny = DestinySys;
}

FlowImpl& FlowImpl::operator=(const Flow& f){
    if (this == &f){
        return *this;
    }

    setName(f.getName());
    setSource(NULL);
    setDestiny(NULL);

    return *this;
}