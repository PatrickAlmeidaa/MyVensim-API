var searchData=
[
  ['logistic_0',['Logistic',['../class_logistic.html',1,'']]]
];
