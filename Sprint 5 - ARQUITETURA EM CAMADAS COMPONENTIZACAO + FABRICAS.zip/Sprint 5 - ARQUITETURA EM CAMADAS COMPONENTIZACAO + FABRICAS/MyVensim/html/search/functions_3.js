var searchData=
[
  ['flowimpl_0',['FlowImpl',['../class_flow_impl.html#aef142b4af715fb4f2f3460c7104804e8',1,'FlowImpl::FlowImpl(const FlowImpl &amp;f)'],['../class_flow_impl.html#a0b26adb31d3c476090d89dffa6b59c90',1,'FlowImpl::FlowImpl(string name=&quot;&quot;, System *Source=NULL, System *Destiny=NULL)']]]
];
