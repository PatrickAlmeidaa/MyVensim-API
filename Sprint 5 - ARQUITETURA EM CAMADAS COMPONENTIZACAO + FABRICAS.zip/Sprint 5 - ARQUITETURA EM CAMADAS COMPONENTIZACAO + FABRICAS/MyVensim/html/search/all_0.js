var searchData=
[
  ['addflow_0',['addFlow',['../class_model.html#aa2ffc7d0e0284d2f78301a246a91bec5',1,'Model::addFlow()'],['../class_model_impl.html#a0414b01f601e6b466d03c84ef2b18dc4',1,'ModelImpl::addFlow()']]],
  ['addsystem_1',['addSystem',['../class_model.html#acfe5022d790c3c71852b394b84023596',1,'Model::addSystem()'],['../class_model_impl.html#a7baffb369cf0b2c42a1c6738196b79a9',1,'ModelImpl::addSystem()']]]
];
