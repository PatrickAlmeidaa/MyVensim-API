#include "unit_tests.h"
#include <iostream>

using namespace std;

int main(){
    run_unit_tests_globals();
    cout << "---Testes finalizados com sucesso---" << endl;
    return 0;
}
