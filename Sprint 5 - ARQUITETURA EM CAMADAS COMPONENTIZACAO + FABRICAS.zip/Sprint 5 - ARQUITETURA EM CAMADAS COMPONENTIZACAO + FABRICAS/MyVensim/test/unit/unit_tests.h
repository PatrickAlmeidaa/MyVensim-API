#ifndef MYVENSIM_UNIT_TESTS_H
#define MYVENSIM_UNIT_TESTS_H

void run_unit_tests_globals();

#endif
