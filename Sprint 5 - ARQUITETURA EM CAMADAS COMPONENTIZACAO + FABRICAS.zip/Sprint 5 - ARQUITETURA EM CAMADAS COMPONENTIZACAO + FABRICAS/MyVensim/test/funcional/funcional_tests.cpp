#include <iostream>
#include <assert.h>
#include <math.h>
#include "funcional_tests.h" 

using namespace std;

void exponentialFuncionalTest(){
    Model* m = Model::createModel("Exponential test", 0.0);
    System* pop1 = m->createSystem("P1", 100);
    System* pop2 = m->createSystem("P2", 0);
    Flow* f = m->createFlow<Exponencial>("test", pop1, pop2);

    assert(pop1->getName() == "P1");
    assert(pop2->getName() == "P2");
    assert(f->getName() == "test");
    assert(m->getName() == "Exponential test");

    assert(fabs(pop1->getValue() - 100.0) < 0.0001);
    assert(fabs(pop2->getValue() - 0.0) < 0.0001);
    assert(fabs(m->getTime() - 0.0) < 0.0001);

    m->execute(0, 100);

    assert(fabs(pop1->getValue() - 36.6032) < 0.0001);
    assert(fabs(pop2->getValue() - 63.3968) < 0.0001);
    assert(fabs(m->getTime() - 100.0) < 0.0001);

    delete (m);
    cout << "Teste exponential rolou" << endl;
}

void logisticalFuncionalTest(){
    Model* m = Model::createModel("Logistic test", 0.0);
    System* p1 = m->createSystem("P1", 100);
    System* p2 = m->createSystem("P2", 10);
    Flow* f = m->createFlow<Logistic>("test", p1, p2);

    assert(p1->getName() == "P1");
    assert(p2->getName() == "P2");
    assert(f->getName() == "test");
    assert(m->getName() == "Logistic test");

    assert(fabs(p1->getValue() - 100.0) < 0.0001);
    assert(fabs(p2->getValue() - 10.0) < 0.0001);
    assert(fabs(m->getTime() - 0.0) < 0.0001);

    m->execute(0, 100);

    assert(fabs(p1->getValue() - 88.2167) < 0.0001);
    assert(fabs(p2->getValue() - 21.7833) < 0.0001);
    assert(fabs(m->getTime() - 100.0) < 0.0001);

    delete(m);
    cout << "Teste logistical rolou" << endl;
}

void complexFuncionalTest(){
    Model* m = Model::createModel("Complex test", 0.0);
    System* q1 = m->createSystem("Q1", 100);
    System* q2 = m->createSystem("Q2", 0);
    System* q3 = m->createSystem("Q3", 100);
    System* q4 = m->createSystem("Q4", 0);
    System* q5 = m->createSystem("Q5", 0);
    Flow* f_f = m->createFlow<Complex>("f", q1, q2);
    Flow* f_t = m->createFlow<Complex>("t", q2, q3);
    Flow* f_u = m->createFlow<Complex>("u", q3, q4);
    Flow* f_v = m->createFlow<Complex>("v", q4, q1);
    Flow* f_g = m->createFlow<Complex>("g", q1, q3);
    Flow* f_r = m->createFlow<Complex>("r", q2, q5);

    assert(q1->getName() == "Q1");
    assert(q2->getName() == "Q2");
    assert(q3->getName() == "Q3");
    assert(q4->getName() == "Q4");
    assert(q5->getName() == "Q5");
    assert(f_f->getName() == "f");
    assert(f_t->getName() == "t");
    assert(f_u->getName() == "u");
    assert(f_v->getName() == "v");
    assert(f_g->getName() == "g");
    assert(f_r->getName() == "r");
    assert(m->getName() == "Complex test");

    assert(fabs(q1->getValue() - 100.0) < 0.0001);
    assert(fabs(q2->getValue() - 0.0) < 0.0001);
    assert(fabs(q3->getValue() - 100.0) < 0.0001);
    assert(fabs(q4->getValue() - 0.0) < 0.0001);
    assert(fabs(q5->getValue() - 0.0) < 0.0001);
    assert(fabs(m->getTime() - 0.0) < 0.0001);

    m->execute(0, 100);

    assert(fabs(q1->getValue() - 31.8513) < 0.0001);
    assert(fabs(q2->getValue() - 18.4003) < 0.0001);
    assert(fabs(q3->getValue() - 77.1143) < 0.0001);
    assert(fabs(q4->getValue() - 56.1728) < 0.0001);
    assert(fabs(q5->getValue() - 16.4612) < 0.0001);
    assert(fabs(m->getTime() - 100.0) < 0.0001);

    delete(m);
    cout << "Teste complex rolou" << endl;
}