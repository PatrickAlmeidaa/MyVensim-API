var indexSectionsWithContent =
{
  0: "acdefgilmnorstuv~",
  1: "ceflmsu",
  2: "fmsu",
  3: "acefgilmorsu~",
  4: "dfnstv",
  5: "fs",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

