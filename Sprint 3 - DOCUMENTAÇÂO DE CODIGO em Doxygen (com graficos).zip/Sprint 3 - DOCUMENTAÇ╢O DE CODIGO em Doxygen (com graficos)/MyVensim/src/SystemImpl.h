#ifndef SYSTEMIMPL_H
#define SYSTEMIMPL_H

#include "System.h"

using namespace std;

class SystemImpl : public System{
protected:
    string name;
    double value;

public:
    SystemImpl (const SystemImpl& stk);

    friend class Flow;
    friend class ModelImpl;

    SystemImpl(string name = "", double value = 0.0);

    virtual ~SystemImpl();

    void setName(string stkName);

    string getName() const;

    void setValue(double stkValue);

    double getValue() const;

    SystemImpl& operator=(const SystemImpl& stk);
};
#endif