#ifndef MODELIMPL_H
#define MODELIMPL_H

#include "./Model.h"

using namespace std;

class ModelImpl : public Model{
protected:
    string name;
    double time;
    vector<System*> Sys;
    vector<Flow*> fl;  

public:             
    typedef vector<System *>::iterator systemIt;
    typedef vector<Flow *>::iterator flowIt;

    systemIt initialSystems();
    systemIt lastSystems();
    flowIt initialFlows();
    flowIt lastFlow();

    ModelImpl(string name="", double time=0.0);

    ~ModelImpl();

    void execute(double start=0.0, double final=0.0);

    void addSystem(System* s);

    void addFlow(Flow* f);

    void setName(string modelName);

    string getName() const;

    void setTime(double currentTime);

    double getTime() const;

    System* getSystem(int index);

    Flow* getFlow(int index);

    ModelImpl (const ModelImpl& model);

    void operator=(const ModelImpl& model);
};

#endif